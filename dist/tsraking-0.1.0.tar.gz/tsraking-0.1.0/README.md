This package implements the TSRAKING procedure developed by Statistics Canada in Python 3.13.1


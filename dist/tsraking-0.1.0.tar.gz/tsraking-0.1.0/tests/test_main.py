from tsrakingpy import main

def test_tsrake():
    pass